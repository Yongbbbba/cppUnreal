#pragma once

class Game
{
public:

	void Init();
	void Update();
};

