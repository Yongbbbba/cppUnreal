#include "pch.h"
#include "Game.h"

void Game::Init()
{
	HelloEngine();
}

void Game::Update()
{

}
